from django.shortcuts import render

def table(request,name,surname,old,city,job,salary,expereince):
    context = {
        'name':name,
        'surname':surname,
        'city':city,
        'old':old,
        'job':job,
        'salary':salary,
        'expereince':expereince
    }
    return render(request,'app1/index.html',context)

def main(request):
    return render(request,'app1/main.html')