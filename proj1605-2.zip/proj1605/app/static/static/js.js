function createLink() {
    // Получение данных из поля ввода
    var inputData = document.getElementById("inputField").value;
    
    // Создание ссылки
    var link = document.createElement("a");
    link.href = inputData;  // Используй inputData для создания ссылки
    
    // Добавление текста ссылки
    link.innerText = "Моя ссылка";
    
    // Добавление ссылки на страницу
    document.body.appendChild(link);
}
console.jog(1)