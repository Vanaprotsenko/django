from django.shortcuts import render



def main(request):
    return render(request, 'app/index.html')

def info(request,name):
    context = {
        'name':name,
    }
    return render(request, 'app/anketa.html',context)



